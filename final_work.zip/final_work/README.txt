Dependências necessárias para a execução dos programas:
	•	opencv
	•	face_recognition
	•	smtplib
	•	selenium e geckodriver se usar o mozilla firefox

———————————————————————————————————————————————————————————————————————————
Para executar o programa de teste:

$python3 test_recognizer.py

———————————————————————————————————————————————————————————————————————————

Para executar o programa final e mais completo (só funciona no horário da aula):

$python3 face_recognizer.py